# App Permission Checker

This app is used to check which application is using which type of permissions.
