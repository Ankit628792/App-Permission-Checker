package in.arjsna.permissionchecker.basemvp;

public interface IMVPView {
}
